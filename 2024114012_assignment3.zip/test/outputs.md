### for morph analyzer:

-    `^walk/walk<verb><inf>/walk<verb><fut>/walk<verb><pres><1p><sg>/walk<verb><pres><1p><pl>/walk<verb><pres><2p><sg>/walk<verb><pres><2p><pl>/walk<verb><pres><3p><pl>$`
    
-    `^walks/walk<verb><pres><3p><sg>$`
    
-    `^walked/walk<verb><pst>$`

-    `^walking/walk<verb><prog>/walk<verb><gnd>$`
    
-    `^talk/talk<verb><inf>/talk<verb><fut>/talk<verb><pres><1p><sg>/talk<verb><pres><1p><pl>/talk<verb><pres><2p><sg>/talk<verb><pres><2p><pl>/talk<verb><pres><3p><pl>$`
    
-    `^jumped/jump<verb><pst>$`
    
-    `^run/run<verb><inf>/run<verb><fut>/run<verb><pres><1p><sg>/run<verb><pres><2p><sg>$`
    
-    `^running/run<verb><prog>/run<verb><gnd>$`
    
-    `^eats/eat<verb><pres><3p><sg>$`
    
-    `^ate/eat<verb><pst>$`

-    `^book/book<noun><sg>$`

-    `^book/book<noun><pl>$`

-    `^children/child<noun><pl>$`

-    `^quicker/quick<adj><cmp>$`

-    `^happiest/happy<adj><sup>$`

### for morph generator:

-    `^walk\<verb\>\<inf\>/walk$`

-    `^walk\<verb\>\<pres\>\<3p\>\<sg\>/walks$`

-    `^walk\<verb\>\<pst\>/walked$`

-    `^walk\<verb\>\<prog\>/walking$`

-    `^talk\<verb\>\<inf\>/talk$`

-    `^jump\<verb\>\<pst\>/jumped$`

-    `^run\<verb\>\<inf\>/run$`

-    `^run\<verb\>\<prog\>/running$`

-    `^eat\<verb\>\<pres\>\<3p\>\<sg\>/eats$`

-    `^eat\<verb\>\<pst\>/ate$`

-    `^book\<noun\>\<sg\>/book$`

-    `^book\<noun\>\<pl\>/books$`

-    `^child\<noun\>\<pl\>/children$`

-    `^slow\<adj\>\<sup\>/slowest$`

-    `^happy\<adj\>\<cmp\>/happier$`