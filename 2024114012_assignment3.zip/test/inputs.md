### for morph analyzer:

-    `walk`    
-    `walks` 
-    `walked`
-    `walking` 
-    `talk` 
-    `jumped`
-    `run`
-    `running`
-    `eats`
-    `ate`
-    `book`
-    `books`
-    `children`
-    `quicker`
-    `happiest`

### for morph generator:
    
-    `walk<verb><inf>`
-    `walk<verb><pres><3p><sg>` 
-    `walk<verb><pst>`    
-    `walk<verb><prog>`    
-    `talk<verb><inf>`    
-    `jump<verb><pst>`    
-    `run<verb><inf>`    
-    `run<verb><prog>`    
-    `eat<verb><pres><3p><sg>`   
-    `eat<verb><pst>`
-    `book<noun><sg>`
-    `book<noun><pl>`
-    `child<noun><pl>`
-    `slow<adj><sup>`
-    `happy<adj><cmp>`